import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  setDoc,
  query,
  orderBy,
  limit,
  Timestamp,
  DocumentData,
} from 'firebase/firestore';
import { db } from './firebase';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function toBool(v: unknown): boolean {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'string') return v === 'true' || v === '1';
  return Boolean(v);
}

function toNum(v: unknown, fallback = 0): number {
  const n = Number(v);
  return isNaN(n) ? fallback : n;
}

function normalizeServer(id: string, data: DocumentData): VpnServer {
  return {
    id,
    name: data.name ?? '',
    host: data.host ?? '',
    port: toNum(data.port, 1194),
    country: data.country ?? '',
    countryCode: data.countryCode ?? '',
    flag: data.flag ?? '',
    protocol: data.protocol ?? 'OpenVPN',
    isActive: toBool(data.isActive),
    isPremium: toBool(data.isPremium ?? data.isVip),
    isFree: toBool(data.isFree),
    load: toNum(data.load),
    ping: toNum(data.ping),
    speedMbps: toNum(data.speedMbps),
    ovpnConfig: data.ovpnConfig ?? '',
  };
}

// Flutter writes subscriptionStatus ('free'|'vip'|'expired'), older records use tier.
// Admin normalises to tier for internal display.
function normalizeUser(id: string, data: DocumentData): AppUser {
  const status = (data.subscriptionStatus ?? data.tier ?? 'free') as string;
  const tier: 'free' | 'vip' = status === 'vip' ? 'vip' : 'free';
  return {
    uid: id,
    email: data.email ?? '',
    displayName: data.displayName ?? '',
    tier,
    subscriptionExpiry: data.premiumExpiry ?? data.subscriptionExpiry ?? null,
    createdAt: data.createdAt,
    usedDataTodayMB: toNum(data.usedDataTodayMB),
  };
}

// ─── Types ────────────────────────────────────────────────────────────────────

export interface VpnServer {
  id?: string;
  name: string;
  host: string;
  port: number;
  country: string;
  countryCode: string;
  flag?: string;
  protocol: string;
  isActive: boolean;
  isPremium: boolean;
  isFree?: boolean;
  load?: number;
  ping?: number;
  speedMbps?: number;
  ovpnConfig?: string;
}

// Field names match Flutter's AppConfigModel exactly
export interface FreeSettings {
  freeDataLimitMB: number;
  freeMaxConnections: number;
  freeServersPerCountry: number;
  allowedCountries: string[];
  blockedCountries: string[];
  maintenanceMode: boolean;
  maintenanceMessage: string;
  vpngateEnabled: boolean;
  vpngateMaxServers: number;
}

// Field names match Flutter's VipPlanModel exactly
export interface VipPlan {
  id: string;
  name: string;
  priceVnd: number;
  durationDays: number;
  features: string[];
  isActive: boolean;
  isPopular?: boolean;
}

export interface VipSettings {
  plans: VipPlan[];
}

export interface AppUser {
  uid?: string;
  email: string;
  displayName: string;
  tier: 'free' | 'vip';
  subscriptionExpiry?: Timestamp | null;
  createdAt?: Timestamp;
  usedDataTodayMB?: number;
}

export interface AppVersion {
  version: string;
  buildNumber: number;
  forceUpdate: boolean;
  minVersion: string;
  releaseNotes: string;
  downloadUrl: string;
  updatedAt?: Timestamp;
}

export interface ConnectionLog {
  id?: string;
  uid: string;
  email?: string;
  serverName: string;
  serverCountry: string;
  connectedAt: Timestamp;
  disconnectedAt?: Timestamp;
  dataMB?: number;
}

export interface NotificationPayload {
  title: string;
  body: string;
  target: 'all' | 'vip' | 'free';
}

export interface DashboardStats {
  totalUsers: number;
  vipUsers: number;
  freeUsers: number;
  totalServers: number;
  activeServers: number;
  maintenanceMode: boolean;
  revenueThisMonth: number;
}

// ─── Servers ──────────────────────────────────────────────────────────────────

export async function getServers(): Promise<VpnServer[]> {
  const snapshot = await getDocs(collection(db, 'servers'));
  return snapshot.docs.map((d) => normalizeServer(d.id, d.data()));
}

export async function addServer(data: Omit<VpnServer, 'id'>): Promise<string> {
  const ref = await addDoc(collection(db, 'servers'), {
    ...data,
    isVip: data.isPremium,                    // Flutter reads isVip
    isFree: data.isFree ?? !data.isPremium,   // Flutter reads isFree
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });
  return ref.id;
}

export async function updateServer(id: string, data: Partial<VpnServer>): Promise<void> {
  const extra: Record<string, unknown> = {};
  if (data.isPremium !== undefined) {
    extra.isVip = data.isPremium;
    extra.isFree = data.isFree ?? !data.isPremium;
  }
  await updateDoc(doc(db, 'servers', id), { ...data, ...extra, updatedAt: Timestamp.now() });
}

export async function deleteServer(id: string): Promise<void> {
  await deleteDoc(doc(db, 'servers', id));
}

export async function toggleServer(id: string, isActive: boolean): Promise<void> {
  await updateDoc(doc(db, 'servers', id), { isActive, updatedAt: Timestamp.now() });
}

// ─── Free Settings ────────────────────────────────────────────────────────────

export async function getFreeSettings(): Promise<FreeSettings> {
  const snap = await getDoc(doc(db, 'app_config', 'free_settings'));
  if (snap.exists()) {
    const d = snap.data();
    // Support both old field names and new Flutter-compatible names
    return {
      freeDataLimitMB: toNum(d.freeDataLimitMB ?? d.dataLimitMB, 500),
      freeMaxConnections: toNum(d.freeMaxConnections ?? d.maxConnections, 1),
      freeServersPerCountry: toNum(d.freeServersPerCountry ?? d.serversPerCountry, 3),
      allowedCountries: d.allowedCountries ?? [],
      blockedCountries: d.blockedCountries ?? [],
      maintenanceMode: toBool(d.maintenanceMode),
      maintenanceMessage: d.maintenanceMessage ?? '',
      vpngateEnabled: d.vpngateEnabled !== undefined ? toBool(d.vpngateEnabled) : true,
      vpngateMaxServers: toNum(d.vpngateMaxServers, 300),
    };
  }
  return {
    freeDataLimitMB: 500,
    freeMaxConnections: 1,
    freeServersPerCountry: 3,
    allowedCountries: [],
    blockedCountries: [],
    maintenanceMode: false,
    maintenanceMessage: '',
    vpngateEnabled: true,
    vpngateMaxServers: 300,
  };
}

export async function saveFreeSettings(settings: FreeSettings): Promise<void> {
  await setDoc(doc(db, 'app_config', 'free_settings'), settings);
}

// ─── VIP Settings ────────────────────────────────────────────────────────────

export async function getVipSettings(): Promise<VipSettings> {
  const snap = await getDoc(doc(db, 'app_config', 'vip_settings'));
  if (snap.exists()) {
    const d = snap.data();
    const plans: VipPlan[] = (d.plans ?? []).map((p: DocumentData) => ({
      id: p.id ?? '',
      name: p.name ?? '',
      priceVnd: toNum(p.priceVnd ?? p.price, 0), // support old 'price' field
      durationDays: toNum(p.durationDays, 30),
      features: p.features ?? [],
      isActive: toBool(p.isActive ?? true),
      isPopular: toBool(p.isPopular),
    }));
    return { plans };
  }
  return { plans: [] };
}

export async function saveVipSettings(settings: VipSettings): Promise<void> {
  await setDoc(doc(db, 'app_config', 'vip_settings'), settings);
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function getUsers(): Promise<AppUser[]> {
  const snapshot = await getDocs(collection(db, 'users'));
  return snapshot.docs.map((d) => normalizeUser(d.id, d.data()));
}

export async function grantVip(uid: string, durationDays: number): Promise<void> {
  const expiry = new Date();
  expiry.setDate(expiry.getDate() + durationDays);
  const expiryTs = Timestamp.fromDate(expiry);
  // Write all field variants so both Flutter app and admin panel stay in sync
  await updateDoc(doc(db, 'users', uid), {
    tier: 'vip',
    subscriptionStatus: 'vip',
    subscriptionExpiry: expiryTs,
    premiumExpiry: expiryTs,
  });
}

export async function revokeVip(uid: string): Promise<void> {
  await updateDoc(doc(db, 'users', uid), {
    tier: 'free',
    subscriptionStatus: 'free',
    subscriptionExpiry: null,
    premiumExpiry: null,
  });
}

// ─── App Version ──────────────────────────────────────────────────────────────

export async function getAppVersion(): Promise<AppVersion> {
  const snap = await getDoc(doc(db, 'app_config', 'app_version'));
  if (snap.exists()) return snap.data() as AppVersion;
  return {
    version: '1.0.0',
    buildNumber: 1,
    forceUpdate: false,
    minVersion: '1.0.0',
    releaseNotes: '',
    downloadUrl: '',
  };
}

export async function saveAppVersion(data: AppVersion): Promise<void> {
  await setDoc(doc(db, 'app_config', 'app_version'), {
    ...data,
    updatedAt: Timestamp.now(),
  });
}

// ─── Connection History ───────────────────────────────────────────────────────

export async function getConnectionLogs(limitCount = 100): Promise<ConnectionLog[]> {
  try {
    const q = query(
      collection(db, 'connections'),
      orderBy('connectedAt', 'desc'),
      limit(limitCount)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ id: d.id, ...d.data() } as ConnectionLog));
  } catch {
    return [];
  }
}

// ─── Notifications ────────────────────────────────────────────────────────────

export async function saveNotificationLog(payload: NotificationPayload): Promise<void> {
  await addDoc(collection(db, 'notifications'), {
    ...payload,
    sentAt: Timestamp.now(),
  });
}

export interface NotificationLog {
  id?: string;
  title: string;
  body: string;
  target: string;
  sentAt: Timestamp;
}

export async function getNotificationLogs(): Promise<NotificationLog[]> {
  try {
    const q = query(collection(db, 'notifications'), orderBy('sentAt', 'desc'), limit(50));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ id: d.id, ...d.data() } as NotificationLog));
  } catch {
    return [];
  }
}

// ─── Admin Check ──────────────────────────────────────────────────────────────

export async function isAdmin(email: string): Promise<boolean> {
  if (!email) return false;
  const snap = await getDoc(doc(db, 'admins', email));
  return snap.exists();
}

// ─── Dashboard Stats ──────────────────────────────────────────────────────────

export async function getDashboardStats(): Promise<DashboardStats> {
  const [usersSnap, serversSnap, freeSettings] = await Promise.all([
    getDocs(collection(db, 'users')),
    getDocs(collection(db, 'servers')),
    getFreeSettings(),
  ]);

  const users = usersSnap.docs.map((d) => d.data() as DocumentData);
  const servers = serversSnap.docs.map((d) => d.data() as DocumentData);

  const vipUsers = users.filter((u) => {
    const status = u.subscriptionStatus ?? u.tier ?? '';
    return status === 'vip';
  }).length;

  const activeServers = servers.filter((s) => toBool(s.isActive)).length;

  return {
    totalUsers: users.length,
    vipUsers,
    freeUsers: users.length - vipUsers,
    totalServers: servers.length,
    activeServers,
    maintenanceMode: freeSettings.maintenanceMode,
    revenueThisMonth: 0,
  };
}
