'use client';

import { useState, useEffect } from 'react';
import { VpnServer, addServer, updateServer } from '@/lib/firestore';

interface ServerModalProps {
  server?: VpnServer | null;
  onClose: () => void;
  onSaved: () => void;
}

const PROTOCOLS = ['OpenVPN', 'WireGuard', 'IKEv2', 'L2TP', 'SSTP', 'VLESS', 'VMess', 'Shadowsocks'];

const COUNTRIES: { name: string; code: string }[] = [
  { name: 'Việt Nam', code: 'VN' },
  { name: 'Hoa Kỳ', code: 'US' },
  { name: 'Nhật Bản', code: 'JP' },
  { name: 'Hàn Quốc', code: 'KR' },
  { name: 'Singapore', code: 'SG' },
  { name: 'Đức', code: 'DE' },
  { name: 'Pháp', code: 'FR' },
  { name: 'Anh', code: 'GB' },
  { name: 'Canada', code: 'CA' },
  { name: 'Úc', code: 'AU' },
  { name: 'Hà Lan', code: 'NL' },
  { name: 'Thụy Điển', code: 'SE' },
  { name: 'Thái Lan', code: 'TH' },
  { name: 'Ấn Độ', code: 'IN' },
  { name: 'Brazil', code: 'BR' },
  { name: 'Thổ Nhĩ Kỳ', code: 'TR' },
  { name: 'Nga', code: 'RU' },
  { name: 'Trung Quốc', code: 'CN' },
  { name: 'Hong Kong', code: 'HK' },
  { name: 'Đài Loan', code: 'TW' },
  { name: 'Malaysia', code: 'MY' },
  { name: 'Indonesia', code: 'ID' },
  { name: 'Philippines', code: 'PH' },
];

const emptyForm: Omit<VpnServer, 'id' | 'createdAt' | 'updatedAt'> = {
  name: '',
  host: '',
  port: 1194,
  country: '',
  countryCode: '',
  protocol: 'OpenVPN',
  isActive: true,
  isPremium: false,
  load: 0,
};

export default function ServerModal({ server, onClose, onSaved }: ServerModalProps) {
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (server) {
      setForm({
        name: server.name,
        host: server.host,
        port: server.port,
        country: server.country,
        countryCode: server.countryCode,
        protocol: server.protocol,
        isActive: server.isActive,
        isPremium: server.isPremium,
        load: server.load ?? 0,
      });
    } else {
      setForm(emptyForm);
    }
  }, [server]);

  const handleCountryChange = (code: string) => {
    const found = COUNTRIES.find((c) => c.code === code);
    setForm((f) => ({
      ...f,
      countryCode: code,
      country: found?.name ?? code,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!form.name.trim()) return setError('Tên máy chủ không được để trống.');
    if (!form.host.trim()) return setError('Host / IP không được để trống.');
    if (!form.countryCode) return setError('Vui lòng chọn quốc gia.');
    if (form.port < 1 || form.port > 65535) return setError('Cổng phải từ 1 đến 65535.');

    setSaving(true);
    try {
      if (server?.id) {
        await updateServer(server.id, form);
      } else {
        await addServer(form);
      }
      onSaved();
      onClose();
    } catch (err) {
      console.error(err);
      setError('Lỗi khi lưu dữ liệu. Vui lòng thử lại.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900">
            {server ? 'Chỉnh sửa máy chủ' : 'Thêm máy chủ mới'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-1 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          )}

          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tên máy chủ <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              placeholder="vd: US Server #1"
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>

          {/* Host */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Host / IP <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={form.host}
              onChange={(e) => setForm((f) => ({ ...f, host: e.target.value }))}
              placeholder="vd: 192.168.1.1 hoặc vpn.example.com"
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>

          {/* Port + Protocol */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Cổng (Port) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                value={form.port}
                onChange={(e) => setForm((f) => ({ ...f, port: Number(e.target.value) }))}
                min={1}
                max={65535}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Giao thức
              </label>
              <select
                value={form.protocol}
                onChange={(e) => setForm((f) => ({ ...f, protocol: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white"
              >
                {PROTOCOLS.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Country */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quốc gia <span className="text-red-500">*</span>
            </label>
            <select
              value={form.countryCode}
              onChange={(e) => handleCountryChange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white"
            >
              <option value="">-- Chọn quốc gia --</option>
              {COUNTRIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.name} ({c.code})
                </option>
              ))}
            </select>
          </div>

          {/* Load */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tải máy chủ (%) <span className="text-gray-400 font-normal">— tùy chọn</span>
            </label>
            <input
              type="number"
              value={form.load}
              onChange={(e) => setForm((f) => ({ ...f, load: Number(e.target.value) }))}
              min={0}
              max={100}
              className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>

          {/* Toggles */}
          <div className="space-y-3 pt-1">
            {/* Is Active */}
            <label className="flex items-center justify-between p-3 bg-gray-50 rounded-xl cursor-pointer">
              <div>
                <p className="text-sm font-medium text-gray-800">Kích hoạt máy chủ</p>
                <p className="text-xs text-gray-400">Máy chủ sẽ hiển thị cho người dùng</p>
              </div>
              <button
                type="button"
                onClick={() => setForm((f) => ({ ...f, isActive: !f.isActive }))}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  form.isActive ? 'bg-indigo-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform ${
                    form.isActive ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </label>

            {/* Is Premium */}
            <label className="flex items-center justify-between p-3 bg-gray-50 rounded-xl cursor-pointer">
              <div>
                <p className="text-sm font-medium text-gray-800">Máy chủ VIP</p>
                <p className="text-xs text-gray-400">Chỉ người dùng VIP mới kết nối được</p>
              </div>
              <button
                type="button"
                onClick={() => setForm((f) => ({ ...f, isPremium: !f.isPremium }))}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  form.isPremium ? 'bg-yellow-400' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform ${
                    form.isPremium ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </label>
          </div>
        </form>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-xl transition-colors"
          >
            Hủy
          </button>
          <button
            type="submit"
            disabled={saving}
            onClick={handleSubmit}
            className="flex items-center gap-2 px-5 py-2 bg-indigo-500 hover:bg-indigo-600 disabled:bg-indigo-300 text-white text-sm font-semibold rounded-xl transition-colors"
          >
            {saving ? (
              <>
                <div className="animate-spin h-4 w-4 border-b-2 border-white rounded-full" />
                Đang lưu...
              </>
            ) : (
              server ? 'Cập nhật' : 'Thêm máy chủ'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
