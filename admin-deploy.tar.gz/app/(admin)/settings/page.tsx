'use client';

import { useEffect, useState } from 'react';
import { getFreeSettings, saveFreeSettings, FreeSettings } from '@/lib/firestore';

const ALL_COUNTRIES = [
  { code: 'VN', name: 'Việt Nam' }, { code: 'US', name: 'Hoa Kỳ' },
  { code: 'JP', name: 'Nhật Bản' }, { code: 'KR', name: 'Hàn Quốc' },
  { code: 'SG', name: 'Singapore' }, { code: 'DE', name: 'Đức' },
  { code: 'FR', name: 'Pháp' }, { code: 'GB', name: 'Anh' },
  { code: 'CA', name: 'Canada' }, { code: 'AU', name: 'Úc' },
  { code: 'NL', name: 'Hà Lan' }, { code: 'TH', name: 'Thái Lan' },
  { code: 'IN', name: 'Ấn Độ' }, { code: 'BR', name: 'Brazil' },
  { code: 'HK', name: 'Hong Kong' }, { code: 'TW', name: 'Đài Loan' },
  { code: 'MY', name: 'Malaysia' }, { code: 'ID', name: 'Indonesia' },
  { code: 'PH', name: 'Philippines' }, { code: 'CN', name: 'Trung Quốc' },
  { code: 'RU', name: 'Nga' }, { code: 'TR', name: 'Thổ Nhĩ Kỳ' },
  { code: 'SE', name: 'Thụy Điển' }, { code: 'CH', name: 'Thụy Sĩ' },
];

function flag(code: string) {
  try {
    const a = code.codePointAt(0)! - 65 + 0x1f1e6;
    const b = code.codePointAt(1)! - 65 + 0x1f1e6;
    return String.fromCodePoint(a) + String.fromCodePoint(b);
  } catch { return '🌍'; }
}

const defaultSettings: FreeSettings = {
  freeDataLimitMB: 500,
  freeMaxConnections: 1,
  freeServersPerCountry: 3,
  allowedCountries: [],
  blockedCountries: [],
  maintenanceMode: false,
  maintenanceMessage: '',
  vpngateEnabled: true,
  vpngateMaxServers: 300,
};

export default function SettingsPage() {
  const [settings, setSettings] = useState<FreeSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const data = await getFreeSettings();
        setSettings(data);
      } catch {
        setError('Không thể tải cài đặt.');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setError('');
    try {
      await saveFreeSettings(settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch {
      setError('Lưu thất bại. Vui lòng thử lại.');
    } finally {
      setSaving(false);
    }
  };

  const toggleCountry = (code: string, list: 'allowed' | 'blocked') => {
    const field = list === 'allowed' ? 'allowedCountries' : 'blockedCountries';
    const otherField = list === 'allowed' ? 'blockedCountries' : 'allowedCountries';
    const current = settings[field];
    if (current.includes(code)) {
      setSettings((s) => ({ ...s, [field]: current.filter((c) => c !== code) }));
    } else {
      setSettings((s) => ({
        ...s,
        [field]: [...current, code],
        [otherField]: s[otherField].filter((c) => c !== code),
      }));
    }
  };

  const availableForAllowed = ALL_COUNTRIES.filter((c) => !settings.allowedCountries.includes(c.code));
  const availableForBlocked = ALL_COUNTRIES.filter(
    (c) => !settings.blockedCountries.includes(c.code) && !settings.allowedCountries.includes(c.code)
  );

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white rounded-2xl border border-gray-100 p-6 animate-pulse h-24" />
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Cài đặt hệ thống</h1>
          <p className="text-sm text-gray-500 mt-1">Cấu hình giới hạn Free, VPNGate và chế độ bảo trì</p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-semibold hover:bg-indigo-700 disabled:opacity-60 transition-colors"
        >
          {saving ? (
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          )}
          {saving ? 'Đang lưu...' : 'Lưu cài đặt'}
        </button>
      </div>

      {error && (
        <div className="mb-4 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">{error}</div>
      )}
      {saved && (
        <div className="mb-4 bg-green-50 border border-green-200 rounded-xl px-4 py-3 text-sm text-green-700 flex items-center gap-2">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          Đã lưu thành công! App Flutter sẽ nhận cài đặt mới ngay.
        </div>
      )}

      <div className="space-y-5">
        {/* Maintenance Mode */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h2 className="text-base font-bold text-gray-900 mb-4">Chế độ bảo trì</h2>
          <label className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
            <div>
              <p className="font-medium text-gray-800">Bật chế độ bảo trì</p>
              <p className="text-sm text-gray-400 mt-0.5">Người dùng sẽ thấy thông báo khi mở app</p>
            </div>
            <button
              type="button"
              onClick={() => setSettings((s) => ({ ...s, maintenanceMode: !s.maintenanceMode }))}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.maintenanceMode ? 'bg-red-500' : 'bg-gray-300'
              }`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                settings.maintenanceMode ? 'translate-x-6' : 'translate-x-1'
              }`} />
            </button>
          </label>
          {settings.maintenanceMode && (
            <div className="mt-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">Thông báo bảo trì</label>
              <textarea
                rows={2}
                value={settings.maintenanceMessage ?? ''}
                onChange={(e) => setSettings((s) => ({ ...s, maintenanceMessage: e.target.value }))}
                placeholder="Hệ thống đang bảo trì, vui lòng thử lại sau..."
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300 resize-none"
              />
            </div>
          )}
        </div>

        {/* Free Limits */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h2 className="text-base font-bold text-gray-900 mb-4">Giới hạn tài khoản Free</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Giới hạn data (MB/ngày)</label>
              <input
                type="number"
                min={0}
                value={settings.freeDataLimitMB}
                onChange={(e) => setSettings((s) => ({ ...s, freeDataLimitMB: Number(e.target.value) }))}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Số kết nối đồng thời</label>
              <input
                type="number"
                min={1}
                max={5}
                value={settings.freeMaxConnections}
                onChange={(e) => setSettings((s) => ({ ...s, freeMaxConnections: Number(e.target.value) }))}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Server tối đa / quốc gia</label>
              <input
                type="number"
                min={1}
                max={20}
                value={settings.freeServersPerCountry}
                onChange={(e) => setSettings((s) => ({ ...s, freeServersPerCountry: Number(e.target.value) }))}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
              />
            </div>
          </div>
        </div>

        {/* VPNGate */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h2 className="text-base font-bold text-gray-900 mb-4">VPNGate</h2>
          <label className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer mb-4">
            <div>
              <p className="font-medium text-gray-800">Bật VPNGate</p>
              <p className="text-sm text-gray-400 mt-0.5">Lấy server miễn phí từ vpngate.net cho tài khoản Free</p>
            </div>
            <button
              type="button"
              onClick={() => setSettings((s) => ({ ...s, vpngateEnabled: !s.vpngateEnabled }))}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.vpngateEnabled ? 'bg-indigo-500' : 'bg-gray-300'
              }`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                settings.vpngateEnabled ? 'translate-x-6' : 'translate-x-1'
              }`} />
            </button>
          </label>
          {settings.vpngateEnabled && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Số server tối đa từ VPNGate</label>
              <input
                type="number"
                min={10}
                max={1000}
                step={10}
                value={settings.vpngateMaxServers}
                onChange={(e) => setSettings((s) => ({ ...s, vpngateMaxServers: Number(e.target.value) }))}
                className="w-48 px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
              />
              <p className="text-xs text-gray-400 mt-1">App Flutter lấy tối đa số server này từ API VPNGate</p>
            </div>
          )}
        </div>

        {/* Allowed Countries */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-start justify-between mb-1">
            <div>
              <h2 className="text-base font-bold text-gray-900">Quốc gia được phép (Whitelist)</h2>
              <p className="text-sm text-gray-400 mt-0.5">
                {settings.allowedCountries.length === 0
                  ? 'Để trống = cho phép tất cả quốc gia'
                  : `Chỉ hiển thị server của ${settings.allowedCountries.length} quốc gia đã chọn`}
              </p>
            </div>
          </div>
          {settings.allowedCountries.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3 mb-3">
              {settings.allowedCountries.map((code) => {
                const c = ALL_COUNTRIES.find((x) => x.code === code);
                return (
                  <span key={code} className="inline-flex items-center gap-1.5 bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full text-sm font-medium">
                    {flag(code)} {c?.name ?? code}
                    <button onClick={() => toggleCountry(code, 'allowed')} className="text-indigo-400 hover:text-indigo-700 ml-0.5">×</button>
                  </span>
                );
              })}
            </div>
          )}
          <select
            value=""
            onChange={(e) => { if (e.target.value) toggleCountry(e.target.value, 'allowed'); }}
            className="mt-2 px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
          >
            <option value="">+ Thêm quốc gia vào whitelist...</option>
            {availableForAllowed.map((c) => (
              <option key={c.code} value={c.code}>{flag(c.code)} {c.name}</option>
            ))}
          </select>
        </div>

        {/* Blocked Countries */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="mb-1">
            <h2 className="text-base font-bold text-gray-900">Quốc gia bị chặn (Blacklist)</h2>
            <p className="text-sm text-gray-400 mt-0.5">Server từ các quốc gia này sẽ bị ẩn khỏi danh sách Free</p>
          </div>
          {settings.blockedCountries.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3 mb-3">
              {settings.blockedCountries.map((code) => {
                const c = ALL_COUNTRIES.find((x) => x.code === code);
                return (
                  <span key={code} className="inline-flex items-center gap-1.5 bg-red-50 text-red-700 px-3 py-1 rounded-full text-sm font-medium">
                    {flag(code)} {c?.name ?? code}
                    <button onClick={() => toggleCountry(code, 'blocked')} className="text-red-400 hover:text-red-700 ml-0.5">×</button>
                  </span>
                );
              })}
            </div>
          )}
          <select
            value=""
            onChange={(e) => { if (e.target.value) toggleCountry(e.target.value, 'blocked'); }}
            className="mt-2 px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300 bg-white"
          >
            <option value="">+ Chặn quốc gia...</option>
            {availableForBlocked.map((c) => (
              <option key={c.code} value={c.code}>{flag(c.code)} {c.name}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}
