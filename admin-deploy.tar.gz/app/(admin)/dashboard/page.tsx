'use client';

import { useEffect, useState } from 'react';
import { getDashboardStats, DashboardStats } from '@/lib/firestore';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  color: 'indigo' | 'green' | 'yellow' | 'red' | 'blue';
  trend?: string;
}

const colorMap = {
  indigo: {
    bg: 'bg-indigo-50',
    icon: 'bg-indigo-500',
    text: 'text-indigo-600',
    badge: 'bg-indigo-100 text-indigo-700',
  },
  green: {
    bg: 'bg-green-50',
    icon: 'bg-green-500',
    text: 'text-green-600',
    badge: 'bg-green-100 text-green-700',
  },
  yellow: {
    bg: 'bg-yellow-50',
    icon: 'bg-yellow-500',
    text: 'text-yellow-600',
    badge: 'bg-yellow-100 text-yellow-700',
  },
  red: {
    bg: 'bg-red-50',
    icon: 'bg-red-500',
    text: 'text-red-600',
    badge: 'bg-red-100 text-red-700',
  },
  blue: {
    bg: 'bg-blue-50',
    icon: 'bg-blue-500',
    text: 'text-blue-600',
    badge: 'bg-blue-100 text-blue-700',
  },
};

function StatCard({ title, value, subtitle, icon, color, trend }: StatCardProps) {
  const c = colorMap[color];
  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-6 flex items-start gap-4 hover:shadow-sm transition-shadow">
      <div className={`${c.icon} p-3 rounded-xl flex-shrink-0`}>
        <span className="text-white">{icon}</span>
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-gray-500 truncate">{title}</p>
        <p className="text-2xl font-bold text-gray-900 mt-0.5">{value}</p>
        {subtitle && <p className="text-xs text-gray-400 mt-1">{subtitle}</p>}
        {trend && (
          <span className={`inline-block text-xs font-medium px-2 py-0.5 rounded-full mt-2 ${c.badge}`}>
            {trend}
          </span>
        )}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const data = await getDashboardStats();
        setStats(data);
      } catch (e) {
        setError('Không thể tải dữ liệu. Kiểm tra kết nối Firebase.');
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const vipPercent = stats && stats.totalUsers > 0
    ? Math.round((stats.vipUsers / stats.totalUsers) * 100)
    : 0;

  return (
    <div>
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Tổng quan</h1>
        <p className="text-sm text-gray-500 mt-1">
          Xem thống kê và trạng thái hệ thống SenVPN
        </p>
      </div>

      {/* Maintenance Banner */}
      {stats?.maintenanceMode && (
        <div className="mb-6 flex items-center gap-3 bg-yellow-50 border border-yellow-200 rounded-xl px-5 py-4">
          <svg className="w-5 h-5 text-yellow-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
          </svg>
          <div>
            <p className="text-sm font-semibold text-yellow-800">Chế độ bảo trì đang BẬT</p>
            <p className="text-xs text-yellow-600">Người dùng sẽ thấy thông báo bảo trì khi mở app.</p>
          </div>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="mb-6 bg-red-50 border border-red-200 rounded-xl px-5 py-4 text-sm text-red-700">
          {error}
        </div>
      )}

      {/* Stat Cards */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-white rounded-2xl border border-gray-100 p-6 animate-pulse">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gray-100 rounded-xl" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 bg-gray-100 rounded w-24" />
                  <div className="h-6 bg-gray-100 rounded w-16" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          <StatCard
            title="Tổng người dùng"
            value={stats?.totalUsers ?? 0}
            subtitle="Tất cả tài khoản đã đăng ký"
            color="indigo"
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" />
              </svg>
            }
          />
          <StatCard
            title="Người dùng VIP"
            value={stats?.vipUsers ?? 0}
            subtitle={`${vipPercent}% tổng người dùng`}
            color="yellow"
            trend="Premium"
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z" />
              </svg>
            }
          />
          <StatCard
            title="Người dùng Free"
            value={stats?.freeUsers ?? 0}
            subtitle={`${100 - vipPercent}% tổng người dùng`}
            color="blue"
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            }
          />
          <StatCard
            title="Tổng máy chủ"
            value={stats?.totalServers ?? 0}
            subtitle="Máy chủ VPN đã cấu hình"
            color="green"
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 14.25h13.5m-13.5 0a3 3 0 01-3-3m3 3a3 3 0 003 3h10.5a3 3 0 003-3m-16.5 0V6.75m0 7.5V6.75m0 0a3 3 0 013-3h10.5a3 3 0 013 3m0 7.5V6.75" />
              </svg>
            }
          />
          <StatCard
            title="Máy chủ đang hoạt động"
            value={stats?.activeServers ?? 0}
            subtitle={`${stats?.totalServers ? stats.totalServers - (stats?.activeServers ?? 0) : 0} đang tắt`}
            color="green"
            trend="Online"
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            }
          />
          <StatCard
            title="Trạng thái bảo trì"
            value={stats?.maintenanceMode ? 'Đang BẬT' : 'Đang TẮT'}
            subtitle="Chế độ bảo trì hệ thống"
            color={stats?.maintenanceMode ? 'red' : 'green'}
            icon={
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 11-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 004.486-6.336l-3.276 3.277a3.004 3.004 0 01-2.25-2.25l3.276-3.276a4.5 4.5 0 00-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085m-1.745 1.437L5.909 7.5H4.5L2.25 3.75l1.5-1.5L7.5 4.5v1.409l4.26 4.26m-1.745 1.437l1.745-1.437m6.615 8.206L15.75 15.75M4.867 19.125h.008v.008h-.008v-.008z" />
              </svg>
            }
          />
        </div>
      )}

      {/* Quick Actions */}
      <div className="mt-8">
        <h2 className="text-base font-semibold text-gray-900 mb-4">Truy cập nhanh</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { href: '/servers', label: 'Quản lý máy chủ', desc: 'Thêm, sửa, xóa VPN servers', color: 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100' },
            { href: '/users', label: 'Quản lý người dùng', desc: 'Cấp VIP, xem tài khoản', color: 'text-green-600 bg-green-50 hover:bg-green-100' },
            { href: '/plans', label: 'Gói đăng ký', desc: 'Cấu hình gói VIP', color: 'text-yellow-600 bg-yellow-50 hover:bg-yellow-100' },
            { href: '/settings', label: 'Cài đặt hệ thống', desc: 'Free tier, bảo trì, quốc gia', color: 'text-blue-600 bg-blue-50 hover:bg-blue-100' },
          ].map((item) => (
            <a
              key={item.href}
              href={item.href}
              className={`${item.color} rounded-xl p-4 block transition-colors`}
            >
              <p className="font-semibold text-sm">{item.label}</p>
              <p className="text-xs mt-0.5 opacity-70">{item.desc}</p>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
