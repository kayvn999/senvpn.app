'use client';

import { useEffect, useState } from 'react';
import { getUsers, AppUser } from '@/lib/firestore';
import { Timestamp } from 'firebase/firestore';

function fmtDate(ts?: Timestamp | null) {
  if (!ts) return '—';
  return ts.toDate().toLocaleDateString('vi-VN');
}

function daysLeft(expiry?: Timestamp | null): number {
  if (!expiry) return 0;
  const ms = expiry.toDate().getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / 86400000));
}

export default function RevenuePage() {
  const [users, setUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    getUsers().then((data) => {
      setUsers(data);
      setLoading(false);
    });
  }, []);

  const vipUsers = users.filter((u) => u.tier === 'vip');
  const activeVip = vipUsers.filter((u) => daysLeft(u.subscriptionExpiry) > 0);
  const expiredVip = vipUsers.filter((u) => daysLeft(u.subscriptionExpiry) === 0);

  const filtered = vipUsers.filter((u) =>
    !search ||
    u.email?.toLowerCase().includes(search.toLowerCase()) ||
    u.displayName?.toLowerCase().includes(search.toLowerCase())
  );

  const stats = [
    { label: 'Tổng VIP', value: vipUsers.length, color: 'text-yellow-600', bg: 'bg-yellow-50' },
    { label: 'VIP còn hạn', value: activeVip.length, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'VIP hết hạn', value: expiredVip.length, color: 'text-red-600', bg: 'bg-red-50' },
    { label: 'Tổng người dùng', value: users.length, color: 'text-indigo-600', bg: 'bg-indigo-50' },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Doanh thu & VIP</h1>
        <p className="text-sm text-gray-500 mt-1">Theo dõi người dùng VIP và trạng thái subscription</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map((s) => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-5`}>
            <p className={`text-2xl font-bold ${s.color}`}>{loading ? '...' : s.value}</p>
            <p className="text-xs text-gray-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* VIP ratio bar */}
      {!loading && users.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-5">
          <h2 className="text-sm font-bold text-gray-900 mb-3">Tỷ lệ chuyển đổi VIP</h2>
          <div className="flex items-center gap-4">
            <div className="flex-1 bg-gray-100 rounded-full h-5 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full transition-all"
                style={{ width: `${Math.round((vipUsers.length / users.length) * 100)}%` }}
              />
            </div>
            <span className="text-sm font-bold text-yellow-600 w-16 text-right">
              {Math.round((vipUsers.length / users.length) * 100)}%
            </span>
          </div>
          <div className="flex gap-6 mt-3 text-xs text-gray-500">
            <span>⭐ VIP: {vipUsers.length} người</span>
            <span>🆓 Free: {users.length - vipUsers.length} người</span>
          </div>
        </div>
      )}

      {/* VIP user list */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-4">
          <p className="text-sm font-semibold text-gray-900">Danh sách VIP</p>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm email..."
            className="px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300 w-64"
          />
        </div>

        {loading ? (
          <div className="p-5 space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-14 bg-gray-50 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-14 h-14 bg-yellow-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <svg className="w-7 h-7 text-yellow-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z" />
              </svg>
            </div>
            <p className="text-gray-500 font-medium">Chưa có người dùng VIP</p>
            <p className="text-sm text-gray-400 mt-1">Cấp VIP cho người dùng trong trang Người dùng</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Người dùng</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden md:table-cell">Ngày hết hạn</th>
                <th className="text-center px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Còn lại</th>
                <th className="text-center px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Trạng thái</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map((u) => {
                const days = daysLeft(u.subscriptionExpiry);
                const isActive = days > 0;
                return (
                  <tr key={u.uid} className="hover:bg-gray-50 transition-colors">
                    <td className="px-5 py-3.5">
                      <p className="font-medium text-gray-900 text-sm">{u.displayName || '—'}</p>
                      <p className="text-xs text-gray-400">{u.email}</p>
                    </td>
                    <td className="px-5 py-3.5 hidden md:table-cell">
                      <p className="text-sm text-gray-600">{fmtDate(u.subscriptionExpiry)}</p>
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <span className={`text-sm font-semibold ${isActive ? 'text-green-600' : 'text-red-500'}`}>
                        {isActive ? `${days} ngày` : 'Hết hạn'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <span className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full font-medium ${
                        isActive ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-green-500' : 'bg-red-500'}`} />
                        {isActive ? 'Đang hoạt động' : 'Hết hạn'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
